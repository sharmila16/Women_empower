import LoginScreen from "./LoginScreen";
import SocialLogin from "./components/social-button/SocialButton";

export default LoginScreen;
export { SocialLogin };
