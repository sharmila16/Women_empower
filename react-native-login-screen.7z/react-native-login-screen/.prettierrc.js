module.exports = {
  bracketSpacing: true,
  jsxBracketSameLine: false,
  singleQuote: false,
  trailingComma: "all",
  tabWidth: 2,
  semi: true,
};
